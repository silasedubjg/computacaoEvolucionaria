class solucao_candidata():
    f=[]
    nome=""
    sp=[]
    np=0
    rank=0
    
    
